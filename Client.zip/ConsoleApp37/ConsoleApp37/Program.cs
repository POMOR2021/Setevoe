﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;

class VotingClient
{
    private TcpClient client;
    private NetworkStream stream;
    private Thread recThread;

    public VotingClient(string ipAddress, int port)
    {
        client = new TcpClient(ipAddress, port);
        stream = client.GetStream();
    }

    public void Start()
    {
        Console.WriteLine("Добрый день!\nВы попали в центр голосования.\nЧтобы выйти из приложения введите команду /exit\nДля продолжения нажмите Enter");
        string input = Console.ReadLine();
        if (input == "/exit")
        {
            Console.WriteLine("Закрытие программы...");
            return;  
        }

        Console.WriteLine("Введите имя:");
        string name = Console.ReadLine();
        SendMessage("/name " + name);

        recThread = new Thread(ReceiveMessages);
        recThread.Start();

        while (true)
        {
            string message = Console.ReadLine();
            if (message == "/exit")
            {
                SendMessage("/exit");
                break;
            }
            SendMessage(message);
        }

        recThread.Join();
        client.Close();
        Console.WriteLine("Клиент завершил работу.");
    }

    private void SendMessage(string message)
    {
        byte[] buffer = Encoding.UTF8.GetBytes(message);
        stream.Write(buffer, 0, buffer.Length);
    }

    private void ReceiveMessages()
    {
        byte[] buffer = new byte[1024];
        while (true)
        {
            int bytesRead = 0;
            try
            {
                bytesRead = stream.Read(buffer, 0, buffer.Length);
            }
            catch
            {
                break;
            }

            if (bytesRead == 0) break;

            string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            Console.WriteLine(message);
        }
    }

    public static void Main(string[] args)
    {
        VotingClient client = new VotingClient("127.0.0.1", 5000);
        client.Start();
    }
}
