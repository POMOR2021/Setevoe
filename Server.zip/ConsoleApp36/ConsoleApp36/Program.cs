﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

class VotingServer
{
    private TcpListener server;
    private List<TcpClient> clients;
    private Dictionary<string, int> votes;
    private Dictionary<string, string> userVotes;
    private List<string> voteOptions;
    private bool isVotingActive;
    private Thread serverThread;
    private System.Timers.Timer votingTimer;

    public VotingServer(string ipAddress, int port)
    {
        server = new TcpListener(IPAddress.Parse(ipAddress), port);
        clients = new List<TcpClient>();
        votes = new Dictionary<string, int>();
        userVotes = new Dictionary<string, string>();
        voteOptions = new List<string> { "Option 1", "Option 2", "Option 3" }; 
        isVotingActive = true;

        foreach (var option in voteOptions)
        {
            votes[option] = 0;
        }

        votingTimer = new System.Timers.Timer(60000); 
        votingTimer.Elapsed += EndVoting;
    }

    public void Start()
    {
        server.Start();
        Console.WriteLine("Сервер запущен");

        serverThread = new Thread(AcceptClients);
        serverThread.Start();

        ListenForShutdownCommand();
    }

    private void AcceptClients()
    {
        while (isVotingActive)
        {
            TcpClient client = server.AcceptTcpClient();
            clients.Add(client);
            Thread clientThread = new Thread(HandleClient);
            clientThread.Start(client);
        }
    }

    private void HandleClient(object obj)
    {
        TcpClient tcpClient = (TcpClient)obj;
        NetworkStream stream = tcpClient.GetStream();
        byte[] buffer = new byte[1024];
        string clientName = "";

        SendToClient(tcpClient, "Варианты для голосования:\n" + string.Join("\n", voteOptions));

        while (isVotingActive)
        {
            int bytesRead = 0;
            try
            {
                bytesRead = stream.Read(buffer, 0, buffer.Length);
            }
            catch
            {
                break;
            }

            if (bytesRead == 0) break;

            string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            Console.WriteLine($"Клиент: {message}");

            if (message.StartsWith("/name "))
            {
                clientName = message.Substring(6);
                SendToClient(tcpClient, "\nВведите номер варианта для голосования (например, 1 для 'Option 1'):");
            }
            else if (int.TryParse(message, out int voteNumber) && voteNumber >= 1 && voteNumber <= voteOptions.Count)
            {
                string option = voteOptions[voteNumber - 1];
                if (!userVotes.ContainsKey(clientName))
                {
                    userVotes[clientName] = option;
                    votes[option]++;
                    BroadcastResults();
                }
                else
                {
                    SendToClient(tcpClient, "Вы уже проголосовали.");
                }
            }
            else if (message == "/exit")
            {
                break;
            }
            else if (message.StartsWith("/shutdown"))
            {
                Console.WriteLine("Сервер завершает работу...");
                isVotingActive = false;
                votingTimer.Stop();
                break;
            }
            else if (message.StartsWith("/add "))
            {
                string newOption = message.Substring(5);
                AddVoteOption(newOption);
            }
            else if (message.StartsWith("/remove "))
            {
                string optionToRemove = message.Substring(8);
                RemoveVoteOption(optionToRemove);
            }
        }

        clients.Remove(tcpClient);
        tcpClient.Close();
    }

    private void SendToClient(TcpClient client, string message)
    {
        NetworkStream stream = client.GetStream();
        byte[] buffer = Encoding.UTF8.GetBytes(message);
        stream.Write(buffer, 0, buffer.Length);
    }

    private void BroadcastResults()
    {
        string results = "Результаты голосования:\n";
        foreach (var vote in votes)
        {
            results += $"{vote.Key}: {vote.Value} голосов\n";
        }

        foreach (var client in clients)
        {
            SendToClient(client, results);
        }
    }

    private void EndVoting(object sender, System.Timers.ElapsedEventArgs e)
    {
        isVotingActive = false;
        votingTimer.Stop();
        Console.WriteLine("Голосование завершено.");

        string results = "Финальные результаты:\n";
        foreach (var vote in votes)
        {
            results += $"{vote.Key}: {vote.Value} голосов\n";
        }
        foreach (var client in clients)
        {
            SendToClient(client, results);
        }

        foreach (var client in clients)
        {
            client.Close();
        }

        server.Stop();
    }

    private void ListenForShutdownCommand()
    {
        while (isVotingActive)
        {
            string command = Console.ReadLine();
            if (command == "/exit")
            {
                Console.WriteLine("Сервер завершает работу...");
                EndVoting(null, null);
                break;
            }
            else if (command == "/shutdown")
            {
                Console.WriteLine("Голосование завершено вручную.");
                EndVoting(null, null);
                break;
            }
        }
    }

    public void AddVoteOption(string option)
    {
        if (!voteOptions.Contains(option))
        {
            voteOptions.Add(option);
            votes[option] = 0;
            BroadcastResults();
        }
        else
        {
            Console.WriteLine("Вариант уже существует.");
        }
    }

    public void RemoveVoteOption(string option)
    {
        if (voteOptions.Contains(option))
        {
            voteOptions.Remove(option);
            votes.Remove(option);
            BroadcastResults();
        }
        else
        {
            Console.WriteLine("Вариант не найден.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        VotingServer server = new VotingServer("127.0.0.1", 5000);
        server.Start();
    }
}
